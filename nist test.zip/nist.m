clc;clear all;
n=15000000;t=20000;
x=zeros(1,n);
y=zeros(1,n);
z=zeros(1,n);
q=zeros(1,n);
x(1)=0.3;y(1)=0.4;q(1)=0.5;z(1)=0.5;
k1=10;k2=10;k3=1;k=0.1;
kd=32;
r=588;
for i=1:n+t
    x(i+1) = k1*cos(y(i)*(1-x(i)));
    y(i+1) = k2*sin(z(i)*(1-y(i)));
    z(i+1) = k3*x(i)*(1-x(i)) +k*cos(q(i))*z(i); 
    q(i+1) = 0.1*q(i)+0.1*z(i);
 
    if i>t
          % dec to IEEE754
                result =q(i+1);  %Change the sequence you want to detect
%        kd=mod(result*(10^50),8)+32;
                if(result<0)
                S = '1';
                else
                S = '0';
                end
                result = abs(result);
                l = 0;
                while(result<1)
                result = result * 2;
                l = l+1;
                end
                j = 0;
                while(result>2)
                result = result/2;
                j = j+1;
                end
                E = l + j;
                if(j == 0)
                E = -E;
                end
                E = E+1023;
                E = dec2bin(E,11);

                M23 =dec2bin(floor((result-1)*2^52),52);
%               r = [S,E,M23];
                c=M23(kd:kd+7);
                b = str2num(c(:))';
                s(1,8*(i-t-1)+1:8*(i-t))=b;  
    end
end
fid = fopen('LGy.e','w');
fprintf(fid,'%g',s);
fclose(fid);